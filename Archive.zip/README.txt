# AssistantGPT iOS App (Final Integrated)

This project integrates the uploaded real AssistantGPT index.html with full AppIcon and Splash.

## How to Build
1. Open `AssistantGPT.xcworkspace` in Xcode.
2. Ensure signing & provisioning is set up.
3. Build and run.
