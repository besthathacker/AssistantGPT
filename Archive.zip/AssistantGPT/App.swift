import SwiftUI

@main
struct AssistantGPTApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
