import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    let htmlFile: String

    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        if let filePath = Bundle.main.path(forResource: "Resources/" + htmlFile, ofType: "html") {
            let url = URL(fileURLWithPath: filePath)
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct ContentView: View {
    var body: some View {
        WebView(htmlFile: "index")
            .edgesIgnoringSafeArea(.all)
    }
}
