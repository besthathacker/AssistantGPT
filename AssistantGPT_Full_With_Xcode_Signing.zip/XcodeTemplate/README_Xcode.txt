# AssistantGPT iOS App Template

This template uses a WebView to load `index.html`. 

**Steps to Use:**
1. Open Xcode.
2. Create a new iOS App project.
3. Replace ContentView.swift with a WebView loader for `index.html`.
4. Add `index.html` to the project bundle.
